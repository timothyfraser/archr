# For each decision
#' @name enum
#' @author Tim Fraser
#' @param i ...
#' @param d data.frame of decision-alternative-ids
#' @param c data.frame of constraints
#' @importFrom dplyr `%>%` filter select
#' @importFrom tidyr expand_grid
enum = function(i = 1, d, c){
  #i = 1
  j = i+1

  di = paste0("d",i)
  dj = paste0("d", j)

  # Get the alternative values for decision i
  datai = d %>% dplyr::filter(did == i) %>% select(altid) %>% setNames(nm = di)
  # Get the alternative values for decision j (where j = i + 1)
  dataj = d %>% dplyr::filter(did == j) %>% dplyr::select(altid) %>% setNames(nm = dj)
  # Get the grid of all combinations
  grid = tidyr::expand_grid(datai, dataj)

  return(grid)
}
#' @name enumerate
#' @title Enumerate Your Decision Tree
#' @author Tim Fraser
#' @param d data.frame of decision-alternative items
#' @param c data.frame of constraints
#' @importFrom dplyr `%>%` inner_join mutate n filter select contains
#' @export
enumerate = function(d = NULL, c = NULL){
  no_d = is.null(d)
  got_c = !is.null(c)
  # If d is not present
  if(no_d){ stop("Need an input dataframe of decision-alternatives 'd'...") }
  # If c is present...
  if(got_c){
    # Here's the decision/alternative values of those to be cut
    c_cut = c %>%
      inner_join(by = c("id_prior"),
                 y = d %>% select(id_prior = id, did_prior = did, altid_prior = altid)) %>%
      inner_join(by = c("id_cut"),
                 y = d %>% select(id_cut = id, did_cut = did, altid_cut = altid)) %>%
      mutate(did_prior = paste0("d", did_prior),
             did_cut = paste0("d", did_cut))

    # For as many constrains as supplied, let's constrain this table of architectures.
    cut_rows = function(data, c_cut){
      for(k in 1:nrow(c_cut)){
        # k = 1
        data = data %>%
          filter(
            # Give me any rows where the prior alternative did NOT occur for the prior decision
            #!!sym(c_cut$did_prior[k]) != c_cut$altid_prior[k] ) |
            if_any(.cols = any_of(c_cut$did_prior[k]), ~.x != c_cut$altid_prior[k] )
            | # OR
              # where the cut alternative did NOT occur for the cut decision
              if_any(.cols = any_of(c_cut$did_cut[k]), ~.x !=  c_cut$altid_cut[k])
            #(  !!sym(c_cut$did_cut[k]) != c_cut$altid_cut[k])
            # Both must happen in order to get cut.
          )
      }
      return(data)
    }

  }



  if(!no_d){
    # Get vector of sorted, unique decision ids (eg. 1, 2, 3, 4)
    dids = sort(unique(d$did))
    # Get total number of decisions
    n_dids = length(dids)
    # If there is just 1 decision, do this...
    if(n_dids == 1){
      gridi = d %>% filter(did == dids[1]) %>% select(d1 = altid)
      # If constraints are supplied, cut rows!
      if(got_c){ gridi = cut_rows(data = gridi, c_cut = c_cut)  }

    # If there are 2 decisions
    }else if(n_dids == 2){
      gridi = enum(i = 1, d = d, c = c)
      # If constraints are supplied, cut rows!
      if(got_c){ gridi = cut_rows(data = gridi, c_cut = c_cut)  }
    }else if(n_dids >= 3){


      # excise the last 2 values,
      # because if i = n, we can't run enum(i = n,...)
      # and if j = n, we can't run enum(i = j = n, ...)
      dids = dids[-c(n_dids, n_dids -1) ]


      # Testing value only
      # i = 1
      for(i in dids){
        # testing values only
        # i = 3
        j = i+1
        di = paste0("d", i)
        dj = paste0("d", j)
        # If i is the first decision, enumerate it
        if(i == 1){ gridi = enum(i = i, d = d, c = c) }
        # Then enumerate the jth decision
        gridj = enum(i = j, d = d, c = c)
        # Now join the ith decision table (including all prior) to the jth
        gridi = inner_join(by = dj, x = gridi, y = gridj, multiple = "all")

        # If constraints are supplied
        # If constraints are supplied, cut rows!
        if(got_c){ gridi = cut_rows(data = gridi, c_cut = c_cut)  }
      }
    }

    # Add architecture ids, and reorganize columns
    gridi = gridi %>% mutate(id = 1:n()) %>% select(id, contains("d"))
    return(gridi)
  }

}


#' @name count_ds
#' @title Count N for Downselecting
#' @description Function to count total number of ways you can select `k` items from `n` items.
#' @author Tim Fraser
#' @param k number of items to choose
#' @param n total number of items available to choose from
#' @note
#' count_ds(k = 2, n = 10)
#' @export

count_ds = function(k, n){
  f_n = factorial(n)
  f_k = factorial(k)
  f_n_minus_k = factorial((n - k))
  result = f_n / (f_k * f_n_minus_k)
  return(result)
}
# tribble(
#   ~id, ~did, ~altid,
#   1,   1,    0,
#   2,   1,    1
# )

#' @name enumerate_binary
#' @author Tim Fraser
#' @description
#' Wrapper function for enumerating `n` binary decisions, using `enumerate()`.
#' @param n number of decisions. Must be at least 1.
#' @importFrom tidyr expand_grid
#' @importFrom dplyr `%>%` mutate tibble
enumerate_binary = function(n = 2){
  # n must be an integer
  error_message = "'n' must be a non-zero integer."
  # Parse n as an integer
  n = as.integer(n)
  # If is NA (eg. not integer) or 0 or less, stop
  if(is.na(n) | n <= 0){ stop(error_message)}
  # Make the decision-alternative grid
  d = expand_grid(
    did = 1:n,
    tibble(altid = c(0,1))
  ) %>% mutate(id = 1:n()) %>%
    mutate(across(.cols = c(did, altid, id), ~as.integer(.x)))

  # Enumerate these decisions
  output = enumerate(d = d, c = NULL)
  return(output)
}







