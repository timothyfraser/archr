---
title: "System Architecture in R"
author: "Timothy Fraser, PhD"
date: "2023-12-25"
site: bookdown::bookdown_site
documentclass: book
bibliography: [book.bib]
biblio-style: apalike
link-citations: yes
description: "Your online textbook for learning system architecture techniques in R! Made for Cornell University Course SYSEN 5400."
---



# Introduction {.unnumbered}

Your online textbook for learning system architecture techniques in R! These coding workshops were made for Cornell University Course SYSEN 5400. Follow along using a Posit.Cloud account or your own local R session!



