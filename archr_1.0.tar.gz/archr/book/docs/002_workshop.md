---
title: "Data Wrangling in R"
author: "Tim Fraser, PhD"
output: 
  rmdformats::downcute:
    default_style: "dark"
    toc_depth: 3
    use_bookdown: TRUE
    df_print: "kable"
---

## Data Wrangling in R {.unnumbered #part_002}



