---
title: "Coding in R"
author: "Tim Fraser, PhD"
output: 
  rmdformats::downcute:
    default_style: "dark"
    toc_depth: 3
    use_bookdown: TRUE
    df_print: "kable"
---

# Workshop: Using R



Welcome to using RStudio Online with `Posit.Cloud`! This is a gentle introduction to coding in RStudio. There are *many* different ways to code. All that matters is that you find a way to code that works for you! That being said, this tutorial will teach you a few strategies that help me a lot when coding.

## Strategies

### 'COMMENT' YOUR CODE! {-}

I comment EVERY LINE OF CODE, explaining to my future self what I am doing in each line of code. Some people comment more than others, but it really, really, really helps.

****To make a comment, use the `#` symbol.

```r
# This is addition!
1 + 1
```

```
## [1] 2
```

### WRITE IT OUT, EVERY TIME! {-}

Type out your code as much as possible, rather than copying and pasting. Your hands will LEARN to code via MUSCLE MEMORY. That's really helpful for speed and memory! Plus, you'll build a granular understanding of how each line of your code works.

### CODE TOP TO BOTTOM! {-}

Code is meant to be run from the top to the bottom of the script. If `x = 2` and `y = 4` and you want to say, `x + y`, you need to have already run `x = 2` and `y = 4` for R to know what `x + y` means. 

### CHECK YOUR CODE OUTPUT AS YOU GO! {-}

I check my code, every line or chunk, as I go. It's tempting to write huge chunks of code and THEN evaluate their output, but unless you're really experienced (and even then) it can be hard to figure out what's missing in your code when the output isn't quite right. It's much clearer if you test each line as you go.

### MAKE A LOT OF MISTAKES! {-}

Coding is an iterative process, full of 'mistakes'. I make coding mistakes ALL THE TIME. Mistakes aren't bad - they are how you figure out what **doesn't** work, so you can find what **does** work.

### IT TAKES A VILLAGE! {-}

Nobody learns to code alone, so don't feel like you have to! Come to office hours! (I love working through code with students!) Meet your classmates in the library! Connect via chat, Github, Discussion Boards, or Discord! 

### FIND YOUR RUBBER DUCK! {-}

'Ducking' refers to talking out your idea or thought process for coding to an inanimate object - eg. a rubber duck. Doesn't have to be a rubber duck - could be a stuffed animal or a wall - but it's important to talk out your thought process with an very non-judgmental audience :)


## Parts of RStudio


```r
# -- SCRIPT (MAIN PANEL)                = write instructions
# -- COMMAND WINDOW/OUTPUT (bottom)     = output
# -- FILE DIRECTORY (lower right)        = long-term memory
# -- WORKSPACE/ENVIRONMENT (upper right) = short-term memory
```


## Coding Fundamentals 

### Use `R` as a Calculator! {-}

Save value(s) as an "object" called `x` to store in your Environment/Workspace (lower left) - like your computer's short-term memory. 


```r
x = 2
```

### Print the output! {-}


```r
# Click CTLR ENTER (or COMMAND ENTER in MAC) to run this chunk of code!
x
```

```
## [1] 2
```

### Compute New Values with Objects! {-}


```r
# We can compute values using your object 'x', 
# and save the result as an object, 'y'
x = 1;
y = x + 2;
y
```

```
## [1] 3
```
### Clear Objects {-}


```r
# To clear a objects from your short-term memory (Environment/Workspace), use 
remove(x)
# To clear ALL objects from your short-term memory, use rm()
rm(list = ls())
# Notice how y is gone now too?
```

### Load Packages for Extra Functions!

Packages (a.k.a. libraries) provided added functionality to `R`. You must install them once with `install.packages("packagename")`, then use `library(packagename)` to turn them on at the beginning of every `R` script.

For example, we will commonly use these 3 packages: `dplyr`, `readr`, and `ggplot2`. Let's install them, then load them, below.


```r
# Install the packages just one time!
install.packages(c("dplyr", "readr", "ggplot2"))
```


```r
# Load the packages!
library(dplyr)
library(readr)
library(ggplot2)
```


## DATA TYPES 

We can encode all sorts of objects! 

- Remember to give your objects clear, short, descriptive names.
- Avoid spaces. 
- Avoid upper case. (Using only lowercase is simpler and yields fewer errors.)
- Underscores can help.

### Make a vector (row or column; R doesn't care.) {-}


```r
myvec = c(1,2,3,4) # commas separate values
# View it!
myvec
```

```
## [1] 1 2 3 4
```

### Make a 1-row matrix (a row of numbers) {-}


```r
myrow = matrix(c(1,2,3,4), nrow = 1)
# View it!
myrow 
```

```
##      [,1] [,2] [,3] [,4]
## [1,]    1    2    3    4
```

### Make a 1-column matrix! (a column of numbers) {-}


```r
mycol = matrix(c(1,2,3,4), ncol = 1)
# View it!
mycol
```

```
##      [,1]
## [1,]    1
## [2,]    2
## [3,]    3
## [4,]    4
```

### Make a matrix from row vectors! (a stack of row vectors!) {-}


```r
# We can stack rows atop each other if we say byrow = TRUE
mymat1 = matrix(c(myrow, myrow, myrow), byrow = TRUE, ncol = 4)
# View it!
mymat1
```

```
##      [,1] [,2] [,3] [,4]
## [1,]    1    2    3    4
## [2,]    1    2    3    4
## [3,]    1    2    3    4
```
### Make a matrix from column vectors! (a bundle of column vectors!) {-}

```r
mymat2 = matrix(c(mycol, mycol, mycol), byrow = FALSE, ncol = 3)
# View it!
mymat2
```

```
##      [,1] [,2] [,3]
## [1,]    1    1    1
## [2,]    2    2    2
## [3,]    3    3    3
## [4,]    4    4    4
```

### Make a matrix from scratch! {-}


```r
# Make it all in one line...
mymat3 = matrix(c(1,2,3,  4,5,6,  7,8,9), byrow = TRUE, nrow = 3, ncol = 3)
# or break it up across multiple lines (clearer to read)
mymat3 = matrix(
  c(1,2,3,
    4,5,6,
    7,8,9),
  byrow = TRUE, nrow = 3, ncol = 3)
# View it!
mymat3 
```

```
##      [,1] [,2] [,3]
## [1,]    1    2    3
## [2,]    4    5    6
## [3,]    7    8    9
```


### Math with Matrices and Vectors! {-}


```r
# Do cell-wise multiplication! (normal multiplication)
mymat3^2   # square each value
```

```
##      [,1] [,2] [,3]
## [1,]    1    4    9
## [2,]   16   25   36
## [3,]   49   64   81
```

```r
mymat3*2   # multiply each value by 2
```

```
##      [,1] [,2] [,3]
## [1,]    2    4    6
## [2,]    8   10   12
## [3,]   14   16   18
```

```r
mymat3 + mymat3   # add two matrices together, cell by cell
```

```
##      [,1] [,2] [,3]
## [1,]    2    4    6
## [2,]    8   10   12
## [3,]   14   16   18
```


```r
# Do Matrix Multiplication!
mymat3 %*% mymat3
```

```
##      [,1] [,2] [,3]
## [1,]   30   36   42
## [2,]   66   81   96
## [3,]  102  126  150
```

### Make a Character/String Vector! {-}


```r
# Must put them in double quotes
mychar = c("corgi", "dalmatian", "pug")
mychar
```

```
## [1] "corgi"     "dalmatian" "pug"
```


```r
# Notice you can't mix and match character and numeric values 
# in a vector or matrix; 
# it becomes a character vector if you do:
c("corgi", "dalmatian", "pug", 3)
```

```
## [1] "corgi"     "dalmatian" "pug"       "3"
```

### Make a `data.frame`  {-}

Data.frames can contain numeric vectors AND character vectors. They are the most common way to encode data in `R`.


```r
# Let's make a data.frame table 't', using the data.frame() function
day = c("M", "T", "W", "R", "F") # make a vector of days
temp = c(30, 20, 25, 27, 29) # make a vector of temperatures

t = data.frame(day, temp)
# make a data.frame with variables day and temp

t # view data.frame!
```

```
##   day temp
## 1   M   30
## 2   T   20
## 3   W   25
## 4   R   27
## 5   F   29
```


### Query a `data.frame`! {-}

Grab a specific vector/column by using `$` to look INTO the data.frame to that column/property. The output can be used like any vector.


```r
t$day # grab a specific vector/column
```

```
## [1] "M" "T" "W" "R" "F"
```

```r
t$temp + 1 # Can do operations on these vectors!
```

```
## [1] 31 21 26 28 30
```

You can ADD vectors to a `data.frame` this way too. Eg. did it snow on these days?

```r
t$snow = c("yes", "no", "yes", "no", "no") 

t # View it!
```

```
##   day temp snow
## 1   M   30  yes
## 2   T   20   no
## 3   W   25  yes
## 4   R   27   no
## 5   F   29   no
```


### Subset a `data.frame`/`matrix`!

Use **brackets** to reach in a grab just specific columns or values.


```r
t[1:3, 2] 
```

```
## [1] 30 20 25
```

```r
# eg. grab rows 1 to 3 from column 2 from data.frame 't'

mymat1[1, 2:4] 
```

```
## [1] 2 3 4
```

```r
# eg. grab row 1 from columns 2, 3, and 4 from matrix 'mymat1'
```

### Remember to Clear Your Workspace!


```r
# Clear Environment variables!
rm(list = ls())
# Clear your console with CTRL + L (or COMMAND + L on MAC)
```

### Read `data.frames` and `matrix` files

It's usually easy to record data in Excel or Sheets, then load those files into R for analysis. 

You can use `read_csv()` from the `readr` package to read in tables!


```r
t = readr::read_csv("../workshops/test_data.csv")
```

Got something in native R data storage format (`.rds`) and want to read it in? Eg. a matrix? Use `read_rds()` from the `readr` package to read in such data.


```r
m = readr::read_rds("../workshops/test_data.rds")
```

### Write `data.frames` and `matrix` data to file

Want to write something to file? Use `readr`'s `write_csv()` or `write_rds()` functions.


```r
# Above, we could have saved it like this!

# For a portable .csv file
readr::write_csv(t, file = "../workshops/test_data.csv")

# Or as a .rds file for native R files
readr::write_rds(as.matrix(t), file = "../workshops/test_data.rds")
```



```r
# Let's clear our workspace
rm(list = ls())
```


## FUNCTIONS 

Functions are powerful tools! They take input(s) and spit out outputs! In R, we can make functions within a script and then execute them in the same script!

### Test out the `plusone()` `function`

What does `plusone()` do?


```r
#' @name plusone
#' @author Tim Fraser
#' @description Adds x +1 and returns y
plusone = function(x){ y = x + 1; return(y) }

# Try this out!
plusone(3)
```

```
## [1] 4
```

```r
plusone(4)
```

```
## [1] 5
```

```r
plusone(5)
```

```
## [1] 6
```

Notice that we name the inputs x, and to return our final output `y`, we must say `return(y)` or end the function with `y`.

### Make your own `plustwo()` `function`!

In your own copy of this script, view the plusone function, and compare. What do you need to change to make a plustwo function, that adds 2 to x? Type it out yourself. (Avoid copying and pasting!)




## Next Steps

Whoohoo! You made it! Great job on these first exercises coding in R.

As we make more code in the coming weeks, you'll get more and more comfortable with coding, but these fundamentals are half the battle!

Happy coding!



## Z. EXTRA {-}

### READ FILES FROM GOOGLE SHEETS {-}

I find a fantastic way to collaborate is to work with shared Google Sheets, get a share link, then lightly adjust it to produce a **download link!**

This is the share link to our "test_data" on Google Sheets.

```r
s_link = "https://docs.google.com/spreadsheets/d/1Bcl0e8upw4QrBIXpuxgnGGTnU_y1FzVdGncYy_A0saY/edit?usp=sharing"

# A minor change will turn it into a download link! (replace "edit?usp=sharing" with "export?format=csv")
d_link = "https://docs.google.com/spreadsheets/d/1Bcl0e8upw4QrBIXpuxgnGGTnU_y1FzVdGncYy_A0saY/export?format=csv"

# Try reading it in!
t2 = readr::read_csv(d_link)
# View it!
t2
```

```
## # A tibble: 6 × 3
##      id coffees  sale
##   <dbl>   <dbl> <dbl>
## 1     1       2  8   
## 2     2       4  4.5 
## 3     3       3  3.5 
## 4     4       2  8   
## 5     5       1  5.75
## 6     6       4  5
```

### CONDITIONS {-}

We also might want to make an if-else statement. We can ask `R` to do a specific task IF a condition is true.


```r
# If 2 is greater than 1, 
if(2 > 1){
  value = "Greater!" # make object value = "Greater!"
}else if(2 < 1){
  value = "Less!" # If less, make value = "Less!"
}else{
  value = "Equal." # If something else, it must be value = "Equal!"
}
value # check out the result!
```

```
## [1] "Greater!"
```


### LOOPS {-}

Loops are a powerful part of algorithms, letting us do repetitive, boring tasks very quickly with the power of computation!

For example, this loop repeats `10` times, and goes to `print()` a value `i*10` when `i` equals `1`, `2`, `3`, `4`, ... and then `10`.


```r
for(i in 1:10){    print(i*10)    }
```

```
## [1] 10
## [1] 20
## [1] 30
## [1] 40
## [1] 50
## [1] 60
## [1] 70
## [1] 80
## [1] 90
## [1] 100
```


