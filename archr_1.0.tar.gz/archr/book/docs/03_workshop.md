---
title: "Stakeholder Analysis in R"
author: "Tim Fraser, PhD"
output: 
  rmdformats::downcute:
    default_style: "dark"
    toc_depth: 3
    use_bookdown: TRUE
    df_print: "kable"
---

# Workshop 1: Stakeholder Analysis in R



## Startup

How do we use stakeholder analysis functions, like the algorithms discussed in class? No need to re-invent the wheel - you can load in functions from the packages below for these functions and then run them!

### Install Packages


```r
# If first time installing these, uncomment and run this code.
# install.packages(c("dplyr", "readr", "ggplot2"))
# install.packages("archr_1.0.tar.gz", type = "source")

# Ever after, just load the libraries you've already installed.

# Load data wrangling and viz packages
library(dplyr)
library(readr)
library(ggplot2)
# Load our system architecture toolkit
library(archr)
```

## Import Edgelist

In `R`, we typically use `igraph`-formatted graph objects to perform network analysis. But when building a network, it's usually easiest to record edges in an table called an **edgelist**, then transform that edgelist into whatever format you need. I recommend using Google Sheets as a place to collaboratively build your edgelist, then download that edgelist. In fact, here's a workflow that will take your Google Sheet's viewable-shared-link and turn it into an `igraph` object called `g`. Here are the steps:

- Find the document ID and sheet `gid` from your Google Sheet (in our case, **[this document](https://docs.google.com/spreadsheets/d/1VL0jSoWRq0CZqhpEMXQUaY7LQuqu5XbWHdgQ38wbawo/edit?usp=sharing)**). 
- Build a download link to a Google Sheet using the `get_sheet()` from `archr`
- Read in the edgelist `.csv` using that download link. 
- Convert the edgelist to an adjacency matrix with `get_adjacency()` from `archr`.
- Convert the adjacency matrix into an `igraph` object `g` using `get_graph()` from `archr`.

You'll use this workflow many times in this course!


```r
# This is our Google Sheets url
# https://docs.google.com/spreadsheets/d/1VL0jSoWRq0CZqhpEMXQUaY7LQuqu5XbWHdgQ38wbawo/edit#gid=0
# Get the 'docid' and sheet 'gid' from the url
link = get_sheet(docid = "1VL0jSoWRq0CZqhpEMXQUaY7LQuqu5XbWHdgQ38wbawo", gid = "0")
# Get the edges from the link
e = link %>% read_csv()
# Turn it into an adjacency matrix
m = get_adjacency(e)
# Get the names of all unique stakeholders too from the columns
names = colnames(m)
# Make a graph object
g = get_graph(a = m)
```

Let's view these objects we made!


```r
# View a few of those edges
e %>% head(3)
```

```
## # A tibble: 3 × 3
##   from    to          value
##   <chr>   <chr>       <dbl>
## 1 Project Vendor        0.5
## 2 Project Distributor   0.3
## 3 Vendor  Project       0.2
```

```r
# View the matrix representation of those edges! 
m
```

```
##             Project Vendor Distributor Customer
## Project         0.0    0.5         0.3      0.0
## Vendor          0.2    0.0         0.2      0.3
## Distributor     0.0    0.0         0.0      0.3
## Customer        0.0    0.2         0.1      0.0
```

```r
# See the names in that matrix!
names
```

```
## [1] "Project"     "Vendor"      "Distributor" "Customer"
```

```r
# And here's the igraph object
g
```

```
## IGRAPH 7b7bd0d DN-- 4 8 -- 
## + attr: name (v/c), value (e/n)
## + edges from 7b7bd0d (vertex names):
## [1] Project    ->Vendor      Project    ->Distributor Vendor     ->Project    
## [4] Vendor     ->Distributor Vendor     ->Customer    Distributor->Customer   
## [7] Customer   ->Vendor      Customer   ->Distributor
```

```r
# We can even make a very low-budget plot of that graph using plot.
plot(g)
```

<img src="03_workshop_files/figure-html/unnamed-chunk-7-1.png" width="672" />

## Stakeholder Importance with `get_scores()`

Next, we're going to use the `get_scores()` function from `archr`, feeding it...

- `g`, our graph object
- `root`, the character string name of the project node.
- `var`, the name of our edge weights in that graph object. By default, `"value"`

For the remaining stakeholder nodes that are *not* the project node, `get_scores()` will output:

- `stakeholder`: the stakeholder name
- `importance`: the importance score for that stakeholder, as the ratio of...
  - `sh_i`: the sum of all cycle scores for project-centric cycles involving that stakeholder.
  - `total`: the sum of all cycle scores for project-centric cycles.
- `relative`: the relative importance of each stakeholder, which sums to 1.


```r
scores = archr::get_scores(g, root = "Project", var = "value")
# View them!
scores
```

```
## # A tibble: 3 × 6
##   rootid  stakeholder   sh_i total importance relative
##   <chr>   <chr>        <dbl> <dbl>      <dbl>    <dbl>
## 1 Project Vendor      0.104  0.104     1        0.935 
## 2 Project Customer    0.0036 0.104     0.0347   0.0325
## 3 Project Distributor 0.0036 0.104     0.0347   0.0325
```

## Interpreting Importance

Cool! So in our example...

- The Vendor has the highest importance, with a score of 1.
- The next highest is the Customer, with a score of 0.035.

As extra options, you can increase the max number of cycles considered with `cutoff` (defaults to 50, which is usually sufficient for very small matrices). Using `square = TRUE` (defaults to `FALSE`), you can optionally square the value of the last edge in each project-centric cycle using `square`, emphasizing what is most important to you (the project).


```r
# For example:
# archr::get_scores(g, root = "Project", var = "value", cutoff = 100, square = TRUE)
```

## Visualize Stakeholder Network

### Network Layout with `get_coords()`

Finally, we can use the `get_coords()` function from `archr` to generate a coordinate layout for our network's nodes, and then we can visualize the contents using `ggplot2` functions. By default, we use a Kamada-Kawai layout, which is quite fast and effective, using `layout = "kk"`. We'll save those coordinates in an object called `gg` (short for, these are our objects for ggplotting!)


```r
# Let's get a list object of nodes and edges, called gg
gg = get_coords(g, layout = "kk")
# We can access those nodes like so...
gg$nodes %>% head(3)
```

```
##          name           x           y
## 1     Project  0.72679703  0.01834969
## 2      Vendor -0.01708136  0.36405543
## 3 Distributor -0.54975137 -0.08286644
```

```r
# And those edges like so...
gg$edges %>% head(3)
```

```
##      from          to value      from_x     from_y        to_x        to_y
## 1 Project      Vendor   0.5  0.72679703 0.01834969 -0.01708136  0.36405543
## 2 Project Distributor   0.3  0.72679703 0.01834969 -0.54975137 -0.08286644
## 3  Vendor     Project   0.2 -0.01708136 0.36405543  0.72679703  0.01834969
```

### Plotting Networks with `ggplot2`

We can plot out the edges using `geom_segment()`, where each line/row has an `x`,`y` (from) coordinate and a `xend`,`yend` (to) coordinate. You can add arrows too with the `grid::arrow()` argument.


```r
g1 = ggplot() +
  geom_segment(
    # Draw data from gg$edges
    data = gg$edges,
    # Map aesthetics, with color as the value
    mapping = aes(x = from_x, y = from_y, xend = to_x, yend = to_y, color = value),
    # Must add this to show arrows
    arrow = grid::arrow(type = "closed")
  )
# View it!
g1
```

<img src="03_workshop_files/figure-html/unnamed-chunk-11-1.png" width="672" />

For best looking results, I suggest using `geom_curve()`, which can add a slight curvature (eg. `curvature = 0.25`).


```r
# Let's make a curve instead
g1 = ggplot() +
  geom_curve(
    data = gg$edges,
    mapping = aes(x = from_x, y = from_y, xend = to_x, yend = to_y, color = value),
    curvature = 0.25, arrow = grid::arrow(type = "closed"))
# View it!
g1
```

<img src="03_workshop_files/figure-html/unnamed-chunk-12-1.png" width="672" />

Then, we can overlay points and text!


```r
g2 = g1 + 
  # Plot points
  geom_point(
    data = gg$nodes,
    mapping = aes(x = x, y = y),
    # Make it a fillable circle (shape = 21), with both a color and fill
    shape = 21, size = 5, color = "white", fill = "black"
  ) +
  # Plot the text
  geom_text(
    data = gg$nodes,
    mapping = aes(x = x, y = y, label = name), 
    # Push the labels up just a bit
    nudge_y = 0.15)
```

And we can finish it off with some themeing, including a blank `theme_void()` with a legend at the bottom and labeling.


```r
g2 +
  theme_void(base_size = 14) +
  # Add as many optional settings here as you like, like
  theme(
    # put legend on the bottom
    legend.position = "bottom",
    # horizontally justify the plot title at 50% (0 = left and 1 = right)
    plot.title = element_text(hjust = 0.5)) +
  # Add some labels
  labs(color = "Value Flow", title = "Stakeholder Network for Technology X") +
  # We can add a color gradient, ranging from 0 to the max
  scale_color_gradient2(mid = "white", high = "red", midpoint = 0)
```

<img src="03_workshop_files/figure-html/unnamed-chunk-14-1.png" width="672" />

<br>
<br>

## Analytic Hierarchy Process

We might also want to evaluate which of several alternatives is the best choice, given several decision-making criteria. Consider a simple question: ***where should we order pizza from?***

Suppose we have 3 possible pizzerias, dubbed "alternatives", including Krazy Karl's, Gino's, and Brooklyn Pie. For the consumer (us), these three alternatives can be evaluated with 4 criteria: `"tastiness"`, `"quality"`, `"price"`, and delivery `"speed"`. We can do a *'pairwise comparison of alternatives'*, where we compare *how much higher or lower* we rate one pizzeria vs. another pizzeria in terms of a specific criteria. For this example, the pairwise comparison of alternatives can be downloaded as an edgelist from [**this Google Sheet.**](https://docs.google.com/spreadsheets/d/1oLixfbnuep9p3purhJUDSdyW6YeGbXaujk6gU1ibaGg/edit?usp=sharing)


```r
# Let's get the pairwise comparison of alternatives
alts = get_sheet(
  docid = "1oLixfbnuep9p3purhJUDSdyW6YeGbXaujk6gU1ibaGg", 
  gid = "0") %>% 
  read_csv()

# We're also going to get the pairwise comparison of criteria, for later
cri = get_sheet(
  docid = "1oLixfbnuep9p3purhJUDSdyW6YeGbXaujk6gU1ibaGg",
  gid = "837220618") %>% 
  read_csv()

# Let's take a peek at the first 4 comparisons.
alts %>% head(4)
```

```
## # A tibble: 4 × 4
##   from   to     value criteria 
##   <chr>  <chr>  <dbl> <chr>    
## 1 Karl's Karl's   1   tastiness
## 2 Gino's Karl's   5   tastiness
## 3 BP     Karl's   0.5 tastiness
## 4 Karl's Gino's   0.2 tastiness
```

For example, looking at the second row, compared to Gino's (`from`), Karl's (`to`) ranks 5 times as good in terms of tastiness. In contrast, in the third row, we see that Karl's (`to`) ranks 0.5 times as good as Gino's (`from`) in terms of tastiness. If we list out every possible comparison, then we end up with a **pairwise comparison of alternatives**, shown in `alts`.

We can use the `archr` package to perform our Analytical Hierarchy Process analysis. To do it all in one fell swoop, use `get_ahp()`.


```r
# Supply your data.frame of pairwise comparison of alternatives 
# and your data.frame of pairwise comparison of criteria
ahp = get_ahp(alternatives = alts, criteria = cri, format = "wide") 
# format is an optional field; defaults to wide.
```

The output object made is a `list()`, meaning we can access its components one by one using `name_of_list$name_of_item`. We can view the table of global priority statistics generated using `ahp$summary`.


```r
ahp$summary
```

```
## # A tibble: 4 × 6
##   alt     price quality  speed tastiness  goal
##   <fct>   <dbl>   <dbl>  <dbl>     <dbl> <dbl>
## 1 BP     0.0329  0.0508 0.109     0.0225 0.216
## 2 Gino's 0.0591  0.152  0.0104    0.210  0.432
## 3 Karl's 0.240   0.0254 0.0438    0.0435 0.352
## 4 total  0.332   0.229  0.164     0.276  1
```

Next, to view consistency statistics, we can check `ahp$consistency`.


```r
ahp$consistency
```

```
## # A tibble: 5 × 6
##   criteria  lambda_max     n       ci    ri       cr
##   <chr>          <dbl> <int>    <dbl> <dbl>    <dbl>
## 1 goal            6.11     4 7.03e- 1  0.9  7.81e- 1
## 2 price           3.51     3 2.57e- 1  0.58 4.43e- 1
## 3 quality         3.00     3 1.67e-13  0.58 2.87e-13
## 4 speed           3.05     3 2.26e- 2  0.58 3.90e- 2
## 5 tastiness       3.00     3 1.13e- 3  0.58 1.94e- 3
```
`lambda_max` shows the $\lambda_{max}$ statistic for each criteria, with the sample size as the number of alternatives under analysis. `ci` shows the consistency index; `ri` shows that random consistency index for that sample size `n`; and `cr` shows the consistency ratio (`ci / ri`).


```r
# clean up
rm(list = ls())
```
