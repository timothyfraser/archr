# Chapter 3: Enumeration {#part_3} 

## Skill: Enumerating Architectures in `R`



Today, we're going to learn how to enumerate architectures in matrix form. **Enumeration** refers to the act of (1) counting the total number of possible architectures that could occur for a series of decisions, and (2) the act of numerically encoding those architectures in a matrix.

We're going to learn how to encode several different canonical types of decisions as matrices. To do so, we're going to make use of several helpful functions in the `dplyr`, `tidyr`, and `readr` packages, core packages in the **tidyverse** family of `R` packages. For this reason, much of our workflow will look like this:

- produce a table of decision-alternative pairs.
- enumerate architectures as a `tibble()` (a dataframe that's easy to read).
- convert the tibble into a matrix (because most optimization procedures expect a matrix).
- save the tibble to a `.csv` file with `readr`'s `write_csv()`, or save the matrix to a `.rds` file with `write_rds()`.

Here's an example workflow.


```r
# Make a tibble of **all** decision-alternative pairs
d = tribble(
  ~did, ~altid,
  1,    0,
  1,    1,
  2,    0,
  2,    1,
  2,    2
)
# Enumerate out all alternatives into a data.frame for each decision,
# and use expand_grid() from tidyr to get a grid of **every combination** of them!
a = expand_grid(
  # Enumerate decision 1 as 1 binary decision, and name its column 1 d1
  enumerate_binary(n = 1) %>% select(d1 = 1),
  # Enumerate decision 2 as 1 binary decision, and name its column 1 d2
  enumerate_binary(n = 1) %>% select(d2 = 1)
)
# Convert from tibble to matrix with as.matrix()
m = a %>% as.matrix()
# To save your architectures, you can...

# save the tibble as a .csv
a %>% write_csv("arch1.csv")

# OR

# save the matrix as a R Data Storage file (.rds)
# Optionally, you can say 'compress = "gz"' to compress the file,
# which helps when you have really, really big architectural matrices
m %>% write_rds(path = "arch1.rds", compress = "gz")
```


### Enumeration Functions

Enumerating a matrix is a tricky data-architecture problem, and so we have developed a number of helper functions to systematize and speed up the process of enumerating complex architectures. Below, we introduce several functions corresponding to each canonical class of architectural decisions.


#### Binary Decisions

There are at least 3 distinct ways to code binary decisions. Suppose we have 2 binary decisions.

We could use `enumerate_binary(n = 2)` to enumerate 2 binary decisions, each with the alternative integer values of `[0, 1]`.


```r
enumerate_binary(n = 2)
```

```
## # A tibble: 4 × 2
##      d1    d2
##   <dbl> <dbl>
## 1     0     0
## 2     0     1
## 3     1     0
## 4     1     1
```


Or, we could enumerate 2 binary decisions separately, and then use `expand_grid()` to get the full set of combinations of those decisions, naming each decision specifically. 

For example, we could pair `enumerate_binary()` with `expand_grid()` like so...


```r
# For example, 
expand_grid(
  enumerate_binary(n = 1) %>% select(d1 = 1),
  enumerate_binary(n = 1) %>% select(d2 = 1)
)
```

```
## # A tibble: 4 × 2
##      d1    d2
##   <dbl> <dbl>
## 1     0     0
## 2     0     1
## 3     1     0
## 4     1     1
```

Or, we could enumerate these decisions using our standard form enumerator, `enumerate_sf()`. This function enumerates alternatives whose values include `[0, 1, 2, 3, 4, etc.]`. Unlike `enumerate_binary()`, it expects as inputs a vector `n` detailing the number of alternatives in each decision. So, `n = c(2, 2)` means I have decision 1 with 2 alternatives and decision 2 with 2 alternatives.


```r
enumerate_sf(n = c(2, 2))
```

```
## # A tibble: 4 × 2
##      d1    d2
##   <dbl> <dbl>
## 1     0     0
## 2     0     1
## 3     1     0
## 4     1     1
```

Or for another example, we could pair `enumerate_sf()` with `expand_grid()` like so...


```r
expand_grid(
  enumerate_sf(n = 2) %>% select(d1 = 1),
  enumerate_sf(n = 2) %>% select(d2 = 1)
)
```

```
## # A tibble: 4 × 2
##      d1    d2
##   <dbl> <dbl>
## 1     0     0
## 2     0     1
## 3     1     0
## 4     1     1
```

#### Standard Form Decisions

Suppose we want to enumerate a matrix with 3 decisions, where decision 1 includes 2 alternatives, decision 2 includes 3 alternatives, and decision 3 includes 4 alternatives. We could use `enumerate_sf(n = c(2,3))` for this purpose!


```r
e = enumerate_sf(n = c(2,3,4))
# These tibbles are getting large, so let's just glimpse them instead.
e %>% glimpse()
```

```
## Rows: 24
## Columns: 3
## $ d1 <dbl> 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1…
## $ d2 <dbl> 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2…
## $ d3 <dbl> 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2…
```
#### Downselecting

Some canonical classes of decisions involve decisions that require multiple columns to encode. Downselecting refers to a *series* of TRUE/FALSE binary decisions, that are all jointly part of the same decision.

For example, we might say, out of 4 ingredients at the store, do you want to buy A, B, C, and D, just A, B, and C, just A, etc. Downselecting decisions can also have limitations, where you can only select a maximum of, say 3 ingredients at a time. (Perhaps your shopping cart has a size limit.) 

We can use `enumerate_ds(n, k)` for this purpose, where `n` is the total number of items under consideration and `k` is the **max number of items** that can be selected. This built-in constraint feature, `k`, is the key reason why we might enumerate using `enumerate_ds()` for several binary choices rather than using `enumerate_binary()` multiple times. 


```r
enumerate_ds(n = 4, k = 3) %>% glimpse()
```

```
## Rows: 15
## Columns: 4
## $ d1_1 <dbl> 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1
## $ d1_2 <dbl> 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1
## $ d1_3 <dbl> 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1
## $ d1_4 <dbl> 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
```
A few tips. If multiple `k` values are supplied, we then only keep rows where any of those numbers of items were selected.


```r
enumerate_ds(n = 4, k = c(2,3)) %>% glimpse()
```

```
## Rows: 10
## Columns: 4
## $ d1_1 <dbl> 0, 0, 0, 0, 1, 1, 1, 1, 1, 1
## $ d1_2 <dbl> 0, 1, 1, 1, 0, 0, 0, 1, 1, 1
## $ d1_3 <dbl> 1, 0, 1, 1, 0, 1, 1, 0, 0, 1
## $ d1_4 <dbl> 1, 1, 0, 1, 1, 0, 1, 0, 1, 0
```
And we can specify the decision id that all these downselecting items are grouped together under using the optional `.did` argument, which always defaults to 1 if not specified.


```r
enumerate_ds(n = 2, k = 2, .did = 3) %>% glimpse()
```

```
## Rows: 4
## Columns: 2
## $ d3_1 <dbl> 0, 0, 1, 1
## $ d3_2 <dbl> 0, 1, 0, 1
```

#### Assignment

Some decisions involve assigning `n` elements from set `a` to `m` elements from set `b` (eg. assigning students to different classes). We can use `enumerate_assignment()` to help us construct assignment matrices between 2 different types of nodes. Here, `n` and `m` refer to the number of nodes on each side of the assignment graph; for example, if `n=2` and `m=3`, there are `n*m = 6` pairings that can potentially be assigned values. 

- We'll record each of these pairings in a separate column, grouped together by the same decision id `d1`, like `d1_a1_b1`, `d1_a1_b2`, `d1_a2_b1`, etc. 

- `k` tells us the maximum number of times that `1` can show up. `n_alts` tells us that there are 2 alternatives, meaning [0,1]. By default, `k = 1`.


```r
enumerate_assignment(n = 2, m = 3, k = 2, n_alts = 2)
```

```
## # A tibble: 22 × 6
##    d1_a1_b1 d1_a1_b2 d1_a1_b3 d1_a2_b1 d1_a2_b2 d1_a2_b3
##       <int>    <int>    <int>    <int>    <int>    <int>
##  1        0        0        0        0        0        0
##  2        0        0        0        0        0        1
##  3        0        0        0        0        1        0
##  4        0        0        0        0        1        1
##  5        0        0        0        1        0        0
##  6        0        0        0        1        0        1
##  7        0        0        0        1        1        0
##  8        0        0        1        0        0        0
##  9        0        0        1        0        0        1
## 10        0        0        1        0        1        0
## # ℹ 12 more rows
```

- If `n_alts` increases to 3 [0,1,2], then `k` must increase to a length 2 vector (eg. `k = c(2,3)`), showing the maximum number of times that `1` can show up, and the maximum number of times that `2` can show up.

- You'll also note that we can add an optional `.did`, which assigns the decision number.


```r
enumerate_assignment(n = 2, m = 3, k = c(2,3), n_alts = 3, .did = 4)
```

```
## # A tibble: 423 × 6
##    d4_a1_b1 d4_a1_b2 d4_a1_b3 d4_a2_b1 d4_a2_b2 d4_a2_b3
##       <int>    <int>    <int>    <int>    <int>    <int>
##  1        0        0        0        0        0        0
##  2        0        0        0        0        0        1
##  3        0        0        0        0        0        2
##  4        0        0        0        0        1        0
##  5        0        0        0        0        1        1
##  6        0        0        0        0        1        2
##  7        0        0        0        0        2        0
##  8        0        0        0        0        2        1
##  9        0        0        0        0        2        2
## 10        0        0        0        1        0        0
## # ℹ 413 more rows
```

We've also created a function that can back-transform from this encoded architecture format to the raw assignment matrix, called `arch_to_assignment()`. Given multiple architectures, it returns a list of matrices, labeled by the architecture `id`. 

For example, below we enumerate and encode an assignment decision called `arch`. We can feed it to `arch_to_assignment()`, and view the first several matrices in the list.


```r
# Produces 42 architectures
arch = enumerate_assignment(n = 2, m = 3, k = 3, n_alts = 2)
# Produces a list of 42 matrices
matrices = arch_to_assignment(arch = arch)
# Let's see the first 2 matrices 
matrices %>% head(2)
```

```
## $`1`
##    b1 b2 b3
## a1  0  0  0
## a2  0  0  0
## 
## $`2`
##    b1 b2 b3
## a1  0  0  0
## a2  0  0  0
```

```r
remove(arch, matrices) # let's clear these
```

#### Adjacency

Some decisions involve connecting multiple elements from the same set to each other. For this, we need an adjacency matrix, referring to a `n`x`n` matrix that encodes alternatives (eg. `c(0,1)`) as connections (often called edges or links) between two elements (often called nodes). 

Technically, every single adjacency matrix is a possible alternative/choice for that decision, but in order to encode this decision in a one-row architecture, we usually break the `n`x`n` matrix into `n*n` columns, each with a single value in it. Like we did with `enumerate_assignment()`, it helps to label these columns as all being part of the same decision, but pertaining to specific pairs in the adjacency matrix. For example, column names might be `d1_a1_a1`, `d1_a1_a2`, `d1_a2_a1`, etc. Unlike with assignment.


```r
enumerate_adjacency(n = 2, k = 2*2, n_alts = 2)
```

```
## # A tibble: 4 × 2
##   d1_a1_a2 d1_a2_a1
##      <int>    <int>
## 1        0        0
## 2        0        1
## 3        1        0
## 4        1        1
```

We've also created a function that back-transforms from this architecture format to the original adjacency matrix, dubbed `arch_to_adjacency()`. This can be useful when evaluating overall metrics for architectures.

For example, let's enumerate a `2x2` adjacency matrix with `n_alts = 2` alternative values `0` or `1`, producing 4 possible architectures, called `arch`. Then, we can back-transform these architectures to show a list of these 4 adjacency matrices.


```r
# Enumerate adjacency matrices as architectures
arch = enumerate_adjacency(n = 2, k = 2*2, n_alts = 2)
# Convert from architecture back to adjacency matrix
matrices = arch_to_adjacency(arch = arch)
# View first 2 matrices
matrices %>% head(2)
```

```
## $`1`
##    a1 a2
## a1  0  0
## a2  0  0
## 
## $`2`
##    a1 a2
## a1  0  0
## a2  1  0
```

```r
remove(arch, matrices) # clean up shop
```

#### Permutation

Next, we can enumerate **permutations**, which describes all the possible ways you can order a set of `n` elements. The `enumerate_permutation()` function generates a series of columns, all sharing the same root decision id (`.did = 1` -> `d1_`). In addition to the total number of elements `n`, we can also specify `k`, the number of elements to select from `n`.

For example, here are all the ways we can permute `k = 2` elements chosen from a full set of `n = 3` elements. If `k` is not specified, it defaults to `n`, meaning you'll get `n` columns.


```r
enumerate_permutation(n = 3, k = 2, .did = 3)
```

```
## # A tibble: 6 × 2
##    d3_1  d3_2
##   <int> <int>
## 1     0     1
## 2     0     2
## 3     1     0
## 4     1     2
## 5     2     0
## 6     2     1
```

#### Partitioning

Further, we might also want to partition a set of `n` elements into `k` groups. This produces `n` columns with one of `k` possible values in each cell. For example, if `n = 3` and `k = 2`, as in our example below, then these `3` elements can be partitioned into 2 groups named `0` or `1`.

Note: Partitioning is an extended version of downselecting. Downselecting is the act of partitioning a set of `n` elements into `k = 2` groups (`0` vs. `1`).


```r
enumerate_partition(n = 3, k = 2) 
```

```
## # A tibble: 8 × 3
##    d1_1  d1_2  d1_3
##   <dbl> <dbl> <dbl>
## 1     0     0     0
## 2     0     0     1
## 3     0     1     0
## 4     0     1     1
## 5     1     0     0
## 6     1     0     1
## 7     1     1     0
## 8     1     1     1
```

Notice that in the first architecture (row 1), all `n = 3` items were partitioned into the same group `0`, while no elements were partitioned into group `1`. When partitioning, it's really important to be specific! We can add the `min_times = c(1,1)` argument, which tells `enumerate_partition()` that for our `k = 2` groups, the first group must have at least `min_times[1] = 1` element, and the second group must have at least `min_times[2] = 1` element in it. As you can see, when specified, `min_times` must always be a vector that is length `k`, one cell per partition/group.


```r
enumerate_partition(n = 3, k = 2, min_times = c(1,1)) 
```

```
## # A tibble: 6 × 3
##    d1_1  d1_2  d1_3
##   <dbl> <dbl> <dbl>
## 1     0     0     1
## 2     0     1     0
## 3     0     1     1
## 4     1     0     0
## 5     1     0     1
## 6     1     1     0
```

We can also specify a max number of members in each partition, using `max_times`. For example, if `max_times = c(2,1)`, then an architecture can be divided such that partition `0` has up to `2` elements, and partition `1` has up to `1` element. 


```r
enumerate_partition(n = 3, k = 2, max_times = c(2,1)) 
```

```
## # A tibble: 3 × 3
##    d1_1  d1_2  d1_3
##   <dbl> <dbl> <dbl>
## 1     0     0     1
## 2     0     1     0
## 3     1     0     0
```
Both `min_times` and `max_times` can be used simultaneously, separately, or not at all. Be sure to think about the conditions under which you are partitioning. For example, if you are dividing 3 toys between 2 children, and your `min_times = c(3,0)`, that means one child (alternative `0`) can receive all the toys, while the other child (alternative `1`) receives *no toys*.

Finally, like all other enumeration functions, the `.did` argument allows you to specify the name of the decision, eg. `d3_`, etc.


```r
enumerate_partition(n = 3, k = 2, min_times = c(3,0), .did = 3) 
```

```
## # A tibble: 1 × 3
##    d3_1  d3_2  d3_3
##   <dbl> <dbl> <dbl>
## 1     0     0     0
```


### Constraints

We might also have constraints! Because we're using `tibbles`, we can use our `tidyverse`, `SQL`-inspired functions from `dplyr` to help us quickly remove/constraint architectures that are not possible. Here are some examples:

#### Dependent Decisions

Suppose we have 2 binary decisions, but if we selected Alternative 1 for Decision 1, Alternative 1 for Decision 2 is no longer possible. 

Suppose we're choosing a car. 

- Decision 1 is the brand, where Chevy = `0` and Tesla = `1`. 
- Decision 2 is the fueltype, where Electric = `0` and Gas = `1`. 
- Tesla does not develop any Gas powered vehicles, so if Tesla = 1, Gas = 1 must not be an option and should be filtered from the data.frame.


```r
# Let's enumerate 2 binary decisions
enumerate_binary(n = 2) %>%
  # Filter to just rows that do NOT have this condition.
  # Notice that I use a condition, wrapped in parentheses,
  # then add a '!' to flip the condition, to say, NOT this.
  filter(!(d1 == 1 & d2 == 1))
```

```
## # A tibble: 3 × 2
##      d1    d2
##   <dbl> <dbl>
## 1     0     0
## 2     0     1
## 3     1     0
```

This kind of operation can be very helpful in swiftly constraining your `tibble`, particularly as the number of decisions grows. For example, below, we compare the number of possible architectures for `8` binary decisions, before and after adding the same constraint from above.


```r
e_before = enumerate_binary(n = 8) 

e_after = enumerate_binary(n = 8) %>%
  filter(!(d1 == 1 & d2 == 1)) 
  
c("Before" = nrow(e_before), "After" = nrow(e_after))
```

```
## Before  After 
##    256    192
```

```r
remove(e_before, e_after) # clean up shop
```

#### Impossible Options

Sometimes, we have alternatives that are simply impossible to have together. For example, say we are designing a chocolate box with 5 gourmet chocolates, flavored as `0` = caramel, `1` = raspberry, `2` = orange, `3` = mint, and `4` = dark. The chocolates will be placed in a single row in the box. We have to decide in what order to place the chocolates, such that they might stay fresh and tasty.

Here, the issue might be that mint chocolate tends to make any chocolates that are too close to them start to taste minty, which would be really gross for caramel, raspberry, or orange. 

So, no matter what, mint (alternative `3`) can only be next to dark chocolate (alternative `4`). This effectively means that mint *must* be on either end of the box

We can make that architecture like so:


```r
# Order k = 5 out of the n = 5 chocolates
e = enumerate_permutation(n = 5, k = 5) %>%
  # Filter to just rows where 
  # the beginning or end of the row 
  # is 'Mint' (element 3)
  filter(d1_1 == 3 | d1_5 == 3)
# See how 3 now always shows up in d1_1 or d1_5?
e %>% glimpse()
```

```
## Rows: 48
## Columns: 5
## $ d1_1 <int> 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3,…
## $ d1_2 <int> 1, 1, 2, 2, 4, 4, 0, 0, 2, 2, 4, 4, 0, 0, 1, 1, 4, 4, 0, 0, 0, 0,…
## $ d1_3 <int> 2, 4, 1, 4, 1, 2, 2, 4, 0, 4, 0, 2, 1, 4, 0, 4, 0, 1, 1, 1, 2, 2,…
## $ d1_4 <int> 4, 2, 4, 1, 2, 1, 4, 2, 4, 0, 2, 0, 4, 1, 4, 0, 1, 0, 2, 4, 1, 4,…
## $ d1_5 <int> 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 4, 1,…
```

```r
remove(e) # clean shop
```

#### Minimum or Maximum Numbers of Elements

Sometimes, we have decisions where you *must* pick at least 1 item. For example, suppose you were sent to the grocery store to buy any of 4 types of fruit (`d1_1` = orange, `d1_2` = banana, `d1_3` = apple, `d1_4` = pear). You must come back with at least 1 type of fruit, or the trip will have been a waste. We can enumerate it, sans constraints, like so: 

```r
e = enumerate_ds(n = 4, k = 4)
e %>% glimpse()
```

```
## Rows: 16
## Columns: 4
## $ d1_1 <dbl> 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1
## $ d1_2 <dbl> 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1
## $ d1_3 <dbl> 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1
## $ d1_4 <dbl> 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
```
The `enumerate_ds()` function is already built to handle a **max** number of elements, `k`, but it can't handle a minimum number of elements. So how would we do that?

*Method 1*: `mutate()` and `filter()`


```r
e1 = e %>%
  # Calculate the total number of times that alternative 1 showed up for each column
  # eg. total times you bought the fruit (1) versus 
  mutate(count = (d1_1 == 1) + (d1_2 == 1) + (d1_3 == 1) + (d1_4 == 1)) %>%
  # Filter to just architectures where anyone bought at least 1 fruit, then drop count
  filter(count >= 1) %>% select(-count) 
# View 
glimpse(e1)
```

```
## Rows: 15
## Columns: 4
## $ d1_1 <dbl> 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1
## $ d1_2 <dbl> 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1
## $ d1_3 <dbl> 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1
## $ d1_4 <dbl> 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
```
*Method 2*: `rowwise()` and `sum()`


```r
e2 = e %>%
  # Group by row
  rowwise() %>%
  # Get the sum of the cells in that row for these columns
  mutate(count = sum(d1_1, d1_2, d1_3, d1_4)) %>%
  ungroup() %>%
  # Filter then drop the count column
  filter(count >= 1) %>% select(-count)
# View it
glimpse(e2)
```

```
## Rows: 15
## Columns: 4
## $ d1_1 <dbl> 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1
## $ d1_2 <dbl> 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1
## $ d1_3 <dbl> 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1
## $ d1_4 <dbl> 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
```
Finally, we could do it use the `rowSums()` base `R` command, plus `filter()`.


```r
e3 = e %>% 
  # Create a new column containing the result of the rowsum of these 4 columns from e
  mutate(count = e %>% select(d1_1:d1_4) %>% rowSums()) %>%
  # then filter and drop the count column
  filter(count >= 1) %>% select(-count)
```

Quick trick: If you want to refer to `e` without having to write it, you could use `{.}` inside a `mutate()` or `dplyr` function that connects to `e`.


```r
e %>%
  mutate(count = {.} %>% select(d1_1:d1_4) %>% rowSums() ) %>%
  head(3)
```

```
## # A tibble: 3 × 5
##    d1_1  d1_2  d1_3  d1_4 count
##   <dbl> <dbl> <dbl> <dbl> <dbl>
## 1     0     0     0     0     0
## 2     0     0     0     1     1
## 3     0     0     1     0     1
```

### Enumeration with Multiple Canonical Classes

Most architectures involve several different canonical classes of decisions. Let's create a real-ish matrix of architectures involving each of these decisions.

You're choosing where to get an apartment. Suppose you have these decisions:

- *Decision 1*: Am I living in town (1), where my 2 friends live, or outside of town (0)? (Binary/Standard Form)
- *Decision 2*: Am I (a1) next-door neighbors with my friend (a2)? (Adjacency)
- *Decision 3*: I have different front and back door keys. Do I give 1 of these keys to 1 of my 3 neighbors? (Assignment)


```r
e = expand_grid(
  # Am I living in town or outside of town?
  enumerate_binary(n = 1, .did = 1),
  # Am I next door neighbors with any of my 2 friends?
  enumerate_adjacency(n = 2, n_alts = 2, diag = FALSE, .did = 2)
) %>%
  # I, person a1, can only be next door neighbors with 
  # my friend person a2, if I live out of town
  # So let's filter OUT any rows where I live out of town but am neighbors with friend a2.
  filter( !(d1 == 0 & d2_a1_a2 == 1 & d2_a2_a1 == 1)) %>%
  # Finally, add an assignment decision
  expand_grid(
    # Do I give k = 1 key to 1 of my neighbors, out of 2 keys and 3 neighbors?
    enumerate_assignment(n = 2, m = 3, k = 1, n_alts = 2, .did = 3)
  )
# Reveals 42 possible assignments.
e %>% glimpse()
```

```
## Rows: 42
## Columns: 9
## $ d1       <dbl> 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0…
## $ d2_a1_a2 <int> 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1…
## $ d2_a2_a1 <int> 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0…
## $ d3_a1_b1 <int> 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1…
## $ d3_a1_b2 <int> 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0…
## $ d3_a1_b3 <int> 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0…
## $ d3_a2_b1 <int> 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0…
## $ d3_a2_b2 <int> 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0…
## $ d3_a2_b3 <int> 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0…
```


```r
remove(e) # clean up
```

### Conclusion

You're all done! You now can enumerate quickly a variety of customized architectures. Be sure to think about your constraints, and comment them out clearly when filtering. It will help you later on! 


```r
# Let's clear our environment before proceeding.
# Enumeration can take up a lot of memory!
rm(list = ls())
```













