# Chapter 4: Evaluation {#part_4} 

## Skill: Tradespace Analysis in `R`



Today, we'll do several exercises! Please try each Example!

### 0. Setup!

In this workshop, you will learn to use nondominated sorting and dominant features analyses on your enumerated and evaluated architectures.

#### Data

We have `10` decisions to make! Each 'decision' has `2` choices (`radix = 2`). Choosing '1' or 'yes' provides a certain amount of cost (\$ cost) and benefit (\$ expected profit), relative to the baseline of '0'; We've encoded this information in a table `donuts`.


```r
donuts = archr::donuts

donuts # View it!
```

```
## # A tibble: 10 × 6
##       id decision     radix benefit  cost ratio
##    <dbl> <chr>        <dbl>   <dbl> <dbl> <dbl>
##  1     1 glazed?          2       3     1 3    
##  2     2 sprinkles?       2       6     5 1.2  
##  3     3 cake donut?      2       9    70 0.129
##  4     4 filling          2       2     1 2    
##  5     5 no eggs?         2       7     6 1.17 
##  6     6 gluten-free?     2       1     2 0.5  
##  7     7 fried?           2       3     2 1.5  
##  8     8 hole?            2      10   100 0.1  
##  9     9 mini?            2       5    10 0.5  
## 10    10 powdered?        2       8    20 0.4
```

Suppose we have 10 binary-decisions to make. We can record all the possible architectures using `enumerate_binary(n = 16)`, which is just a simple wrapper around our `enumerate()` function.


```r
# Get n = 10 decisions from our donut dataframe
n_d = length(donuts$id)
# Get data.frame 'a' of architectures (rows) for 16 decisions (cols)
a = enumerate_binary(n = n_d)
head(a, 4) # see first 4 rows
```

```
## # A tibble: 4 × 10
##      d1    d2    d3    d4    d5    d6    d7    d8    d9   d10
##   <dbl> <dbl> <dbl> <dbl> <dbl> <dbl> <dbl> <dbl> <dbl> <dbl>
## 1     0     0     0     0     0     0     0     0     0     0
## 2     0     0     0     0     0     0     0     0     0     1
## 3     0     0     0     0     0     0     0     0     1     0
## 4     0     0     0     0     0     0     0     0     1     1
```

### 1. COST & BENEFIT CALCULATION

For 5 architectures (rows), we can calculate the total benefit obtained from all 10 decisions per architecture. Let's use 5 architectures `somearch` as an example.




































